package com.example.ui

import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.AppointmentEntity
import com.example.data.DoctorEntity
import com.example.data.NotificationEntity
import com.example.data.PrescriptionEntity
import com.example.viewmodel.BookNhealViewModel
import com.example.ui.theme.MyApplicationTheme
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@Composable
fun BookNhealApp(viewModel: BookNhealViewModel) {
    val isDark by viewModel.isDarkMode.collectAsStateWithLifecycle()
    val user by viewModel.currentUser.collectAsStateWithLifecycle()
    val isOnboarded by viewModel.isOnboarded.collectAsStateWithLifecycle()

    var currentScreen by remember { mutableStateOf("splash") }

    // Navigation trigger based on state
    LaunchedEffect(user, isOnboarded) {
        if (currentScreen == "splash") {
            delay(2200) // Beautiful cinematic timing for splash screen
            if (!isOnboarded) {
                currentScreen = "onboarding"
            } else if (user == null) {
                currentScreen = "auth"
            } else {
                currentScreen = "dashboard"
            }
        } else if (currentScreen == "onboarding" && isOnboarded) {
            currentScreen = if (user == null) "auth" else "dashboard"
        } else if (currentScreen == "auth" && user != null) {
            currentScreen = "dashboard"
        } else if (currentScreen == "dashboard" && user == null) {
            currentScreen = "auth"
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        when (currentScreen) {
            "splash" -> SplashScreen()
            "onboarding" -> OnboardingScreen(onFinish = {
                viewModel.isOnboarded.value = true
            })
            "auth" -> AuthScreen(viewModel = viewModel)
            "dashboard" -> DashboardNavigator(viewModel = viewModel)
        }
    }
}

// ==========================================
// 1. SPLASH SCREEN
// ==========================================
@Composable
fun SplashScreen() {
    val infiniteTransition = rememberInfiniteTransition(label = "pulse")
    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 0.95f,
        targetValue = 1.05f,
        animationSpec = infiniteRepeatable(
            animation = tween(1100, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "scale"
    )

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(
                        Color(0xFF0F172A),
                        Color(0xFF070B14)
                    )
                )
            ),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            // Heartline pulse and cross visual
            Box(
                modifier = Modifier
                    .size(105.dp)
                    .graphicsLayer {
                        scaleX = pulseScale
                        scaleY = pulseScale
                    }
                    .background(
                        Brush.radialGradient(
                            colors = listOf(Color(0xFF0E63E5).copy(alpha = 0.35f), Color.Transparent)
                        ),
                        shape = CircleShape
                    ),
                contentAlignment = Alignment.Center
            ) {
                // Cross design + Pulse
                Canvas(modifier = Modifier.size(60.dp)) {
                    val w = size.width
                    val h = size.height
                    // Draw outer border circle
                    drawCircle(
                        color = Color(0xFF00B4D8),
                        radius = w / 2,
                        style = Stroke(width = 4.dp.toPx())
                    )
                    // Draw inner centered cross
                    val cx = w / 2
                    val cy = h / 2
                    val armLength = 16.dp.toPx()
                    val thickness = 6.dp.toPx()
                    // Horizontal
                    drawLine(
                        color = Color.White,
                        start = androidx.compose.ui.geometry.Offset(cx - armLength, cy),
                        end = androidx.compose.ui.geometry.Offset(cx + armLength, cy),
                        strokeWidth = thickness,
                        cap = StrokeCap.Round
                    )
                    // Vertical
                    drawLine(
                        color = Color.White,
                        start = androidx.compose.ui.geometry.Offset(cx, cy - armLength),
                        end = androidx.compose.ui.geometry.Offset(cx, cy + armLength),
                        strokeWidth = thickness,
                        cap = StrokeCap.Round
                    )
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            Text(
                text = "BookNheal",
                fontWeight = FontWeight.ExtraBold,
                fontSize = 36.sp,
                color = Color.White,
                letterSpacing = 2.sp
            )

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = "Smart Healthcare Simplified",
                fontSize = 15.sp,
                fontWeight = FontWeight.Light,
                color = Color(0xFF94A3B8),
                letterSpacing = 1.sp
            )

            Spacer(modifier = Modifier.height(64.dp))

            CircularProgressIndicator(
                color = Color(0xFF00B4D8),
                strokeWidth = 3.dp,
                modifier = Modifier.size(36.dp)
            )

            Spacer(modifier = Modifier.height(32.dp))

            Text(
                text = "Newtogen Private Limited",
                fontSize = 12.sp,
                fontWeight = FontWeight.Medium,
                color = Color(0xFF475569)
            )
        }
    }
}

// ==========================================
// 2. ONBOARDING SCREENS
// ==========================================
@Composable
fun OnboardingScreen(onFinish: () -> Unit) {
    var currentPage by remember { mutableStateOf(0) }
    val pageCount = 3

    val onboardingTitles = listOf(
        "Find Trusted Doctors Easily",
        "Book Appointments Instantly",
        "Consult Online Securely"
    )

    val onboardingDescriptions = listOf(
        "Browse verified specialists across 6 diagnostics departments with genuine clinical experience and hospital ratings.",
        "Secure convenient dates and micro slots directly. Re-schedule or cancel from your electronic health records effortlessly.",
        "Experience HD continuous telemedicine streaming call layouts, in-app clinical chat overlays, and digital verified prescription syncs."
    )

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF0F172A))
            .padding(24.dp)
    ) {
        Column(
            modifier = Modifier.fillMaxSize(),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            // Header skip row
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 16.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "BookNheal",
                    fontWeight = FontWeight.Bold,
                    fontSize = 18.sp,
                    color = Color.White
                )

                TextButton(onClick = onFinish) {
                    Text("Skip", color = Color(0xFF00B4D8), fontSize = 15.sp)
                }
            }

            // Central Interactive Graphic Simulation
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(280.dp)
                    .align(Alignment.CenterHorizontally),
                contentAlignment = Alignment.Center
            ) {
                when (currentPage) {
                    0 -> OnboardingGraphicDept()
                    1 -> OnboardingGraphicBooking()
                    2 -> OnboardingGraphicVideo()
                }
            }

            // Title & Text
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 8.dp)
            ) {
                Text(
                    text = onboardingTitles[currentPage],
                    fontWeight = FontWeight.ExtraBold,
                    fontSize = 26.sp,
                    color = Color.White,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(16.dp))

                Text(
                    text = onboardingDescriptions[currentPage],
                    fontSize = 14.sp,
                    color = Color(0xFF94A3B8),
                    textAlign = TextAlign.Center,
                    lineHeight = 22.sp,
                    modifier = Modifier.fillMaxWidth()
                )
            }

            // Indicator and Navigation
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 24.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Dot indicators
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    for (i in 0 until pageCount) {
                        Box(
                            modifier = Modifier
                                .height(6.dp)
                                .width(if (i == currentPage) 20.dp else 6.dp)
                                .clip(RoundedCornerShape(3.dp))
                                .background(if (i == currentPage) Color(0xFF0E63E5) else Color(0xFF475569))
                        )
                    }
                }

                // Next Button
                Button(
                    onClick = {
                        if (currentPage < pageCount - 1) {
                            currentPage++
                        } else {
                            onFinish()
                        }
                    },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Color(0xFF0E63E5)
                    ),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Text(if (currentPage == pageCount - 1) "Get Started" else "Next")
                    Spacer(modifier = Modifier.width(8.dp))
                    Icon(
                        imageVector = Icons.Default.ArrowForward,
                        contentDescription = "Next Icon",
                        modifier = Modifier.size(16.dp)
                    )
                }
            }
        }
    }
}

@Composable
fun OnboardingGraphicDept() {
    // Dynamic floating list of specialist badges
    Box(contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                OnboardingBadge("Cardiology", Icons.Default.Favorite, Color(0xFFEF4444))
                OnboardingBadge("Dental", Icons.Default.Face, Color(0xFF3B82F6))
            }
            Spacer(modifier = Modifier.height(12.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                OnboardingBadge("Dermatology", Icons.Default.Face, Color(0xFF10B981))
                OnboardingBadge("Neurology", Icons.Default.Star, Color(0xFF8B5CF6))
            }
        }
    }
}

@Composable
fun OnboardingGraphicBooking() {
    Box(
        modifier = Modifier
            .fillMaxWidth(0.8f)
            .background(Color(0xFF1E293B), RoundedCornerShape(16.dp))
            .border(1.dp, Color(0xFF334155), RoundedCornerShape(16.dp))
            .padding(16.dp)
    ) {
        Column {
            Text("Confirm Appointment", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
            Spacer(modifier = Modifier.height(8.dp))
            HorizontalDivider(color = Color(0xFF334155))
            Spacer(modifier = Modifier.height(8.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.DateRange, "Date", tint = Color(0xFF00B4D8), modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Text("May 30, 22:30 AM", color = Color(0xFF94A3B8), fontSize = 12.sp)
            }
            Spacer(modifier = Modifier.height(8.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Check, "Checked", tint = Color(0xFF10B981), modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Text("Doctor Available Now", color = Color(0xFF10B981), fontSize = 12.sp, fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
fun OnboardingGraphicVideo() {
    Box(
        modifier = Modifier
            .size(180.dp)
            .background(Color(0xFF1E293B), RoundedCornerShape(20.dp))
            .border(2.dp, Color(0xFF0E63E5), RoundedCornerShape(20.dp)),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(Icons.Default.PlayArrow, "Video Call", tint = Color(0xFF10B981), modifier = Modifier.size(48.dp))
            Spacer(modifier = Modifier.height(8.dp))
            Text("Telemedicine Active", color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 12.sp)
            Text("Encrypted Pipeline", color = Color(0xFF94A3B8), fontSize = 10.sp)
        }
    }
}

@Composable
fun OnboardingBadge(text: String, icon: ImageVector, color: Color) {
    Row(
        modifier = Modifier
            .background(Color(0xFF1E293B), RoundedCornerShape(12.dp))
            .border(1.dp, Color(0xFF334155), RoundedCornerShape(12.dp))
            .padding(horizontal = 12.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, text, tint = color, modifier = Modifier.size(18.dp))
        Spacer(modifier = Modifier.width(8.dp))
        Text(text, color = Color.White, fontSize = 13.sp)
    }
}

// ==========================================
// 3. AUTHENTICATION MODULE (LOGIN / REGISTRATION)
// ==========================================
@Composable
fun AuthScreen(viewModel: BookNhealViewModel) {
    var isNewAccount by remember { mutableStateOf(false) }
    val authError by viewModel.authError.collectAsStateWithLifecycle()
    val isLoader by viewModel.isAuthLoading.collectAsStateWithLifecycle()

    var userName by remember { mutableStateOf("") }
    var email by remember { mutableStateOf("") }
    var phone by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var confirmPassword by remember { mutableStateOf("") }

    var localError by remember { mutableStateOf<String?>(null) }
    var showForgotPassword by remember { mutableStateOf(false) }
    var forgotEmail by remember { mutableStateOf("") }
    var showOtpDialog by remember { mutableStateOf(false) }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF0F172A)),
        contentAlignment = Alignment.Center
    ) {
        Card(
            modifier = Modifier
                .fillMaxWidth(0.92f)
                .wrapContentHeight()
                .shadow(16.dp, RoundedCornerShape(24.dp)),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B)),
            shape = RoundedCornerShape(24.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(24.dp)
                    .verticalScroll(rememberScrollState()),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // Header Logo icon
                Box(
                    modifier = Modifier
                        .size(48.dp)
                        .background(Color(0xFF0E63E5).copy(alpha = 0.2f), CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Add,
                        contentDescription = "Medical Plus Logo",
                        tint = Color(0xFF00B4D8),
                        modifier = Modifier.size(24.dp)
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                Text(
                    text = "BookNheal Health ID",
                    fontWeight = FontWeight.Bold,
                    fontSize = 20.sp,
                    color = Color.White
                )

                Text(
                    text = if (isNewAccount) "Create personal health portfolio" else "Sign in to unified medical passport",
                    fontSize = 12.sp,
                    color = Color(0xFF94A3B8)
                )

                Spacer(modifier = Modifier.height(20.dp))

                // Error feedback
                val displayError = localError ?: authError
                if (displayError != null) {
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 12.dp),
                        colors = CardDefaults.cardColors(containerColor = Color(0xFFEF4444).copy(alpha = 0.15f))
                    ) {
                        Text(
                            text = displayError,
                            color = Color(0xFFFCA5A5),
                            fontSize = 13.sp,
                            modifier = Modifier.padding(12.dp),
                            textAlign = TextAlign.Center
                        )
                    }
                }

                // Forms
                if (isNewAccount) {
                    OutlinedTextField(
                        value = userName,
                        onValueChange = { userName = it },
                        label = { Text("Full Name") },
                        leadingIcon = { Icon(Icons.Default.Person, "Name") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = Color(0xFF0E63E5),
                            unfocusedBorderColor = Color(0xFF475569),
                            focusedLabelColor = Color(0xFF00B4D8),
                            unfocusedLabelColor = Color(0xFF94A3B8),
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White
                        )
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                }

                OutlinedTextField(
                    value = email,
                    onValueChange = { email = it },
                    label = { Text("Email Address") },
                    leadingIcon = { Icon(Icons.Default.Person, "Email") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = Color(0xFF0E63E5),
                        unfocusedBorderColor = Color(0xFF475569),
                        focusedLabelColor = Color(0xFF00B4D8),
                        unfocusedLabelColor = Color(0xFF94A3B8),
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White
                    )
                )

                if (isNewAccount) {
                    Spacer(modifier = Modifier.height(12.dp))
                    OutlinedTextField(
                        value = phone,
                        onValueChange = { phone = it },
                        label = { Text("Phone Number") },
                        leadingIcon = { Icon(Icons.Default.Phone, "Phone") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = Color(0xFF0E63E5),
                            unfocusedBorderColor = Color(0xFF475569),
                            focusedLabelColor = Color(0xFF00B4D8),
                            unfocusedLabelColor = Color(0xFF94A3B8),
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White
                        )
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                OutlinedTextField(
                    value = password,
                    onValueChange = { password = it },
                    label = { Text("Password") },
                    leadingIcon = { Icon(Icons.Default.Lock, "Lock") },
                    visualTransformation = PasswordVisualTransformation(),
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = Color(0xFF0E63E5),
                        unfocusedBorderColor = Color(0xFF475569),
                        focusedLabelColor = Color(0xFF00B4D8),
                        unfocusedLabelColor = Color(0xFF94A3B8),
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White
                    )
                )

                if (isNewAccount) {
                    Spacer(modifier = Modifier.height(12.dp))
                    OutlinedTextField(
                        value = confirmPassword,
                        onValueChange = { confirmPassword = it },
                        label = { Text("Confirm Password") },
                        leadingIcon = { Icon(Icons.Default.Lock, "Lock") },
                        visualTransformation = PasswordVisualTransformation(),
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = Color(0xFF0E63E5),
                            unfocusedBorderColor = Color(0xFF475569),
                            focusedLabelColor = Color(0xFF00B4D8),
                            unfocusedLabelColor = Color(0xFF94A3B8),
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White
                        )
                    )
                }

                if (!isNewAccount) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.End
                    ) {
                        TextButton(onClick = { showForgotPassword = true }) {
                            Text("Forgot Password?", color = Color(0xFF00B4D8), fontSize = 12.sp)
                        }
                    }
                } else {
                    Spacer(modifier = Modifier.height(16.dp))
                }

                // Sign-In/Register Buttons
                Button(
                    onClick = {
                        localError = null
                        if (email.isBlank() || password.isBlank()) {
                            localError = "Please fill in all primary fields."
                            return@Button
                        }
                        if (isNewAccount) {
                            if (userName.isBlank() || phone.isBlank()) {
                                localError = "Full name and Phone are mandatory."
                                return@Button
                            }
                            if (password != confirmPassword) {
                                localError = "Passwords do not match."
                                return@Button
                            }
                            viewModel.register(userName, email, phone, password, onSuccess = {})
                        } else {
                            viewModel.login(email, password, onSuccess = {})
                        }
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(50.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0E63E5)),
                    shape = RoundedCornerShape(12.dp),
                    enabled = !isLoader
                ) {
                    if (isLoader) {
                        CircularProgressIndicator(color = Color.White, modifier = Modifier.size(24.dp))
                    } else {
                        Text(if (isNewAccount) "Create Account" else "Sign In")
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Simulated Social Buttons
                OutlinedButton(
                    onClick = {
                        // Google Sign-In Simulation
                        viewModel.login("demopatient@gmail.com", "password", onSuccess = {})
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp),
                    shape = RoundedCornerShape(12.dp),
                    border = BorderStroke(1.dp, Color(0xFF475569))
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Check,
                            contentDescription = "Check Logo",
                            tint = Color(0xFF34A853),
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Text("Demo Patient Access Express", color = Color.White, fontSize = 13.sp)
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Toggle tabs
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.Center,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = if (isNewAccount) "Already have an account?" else "Don't have an account?",
                        color = Color(0xFF94A3B8),
                        fontSize = 13.sp
                    )
                    TextButton(onClick = {
                        localError = null
                        isNewAccount = !isNewAccount
                    }) {
                        Text(
                            text = if (isNewAccount) "Sign In" else "Sign Up",
                            color = Color(0xFF00B4D8),
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp
                        )
                    }
                }
            }
        }
    }

    // Modal dialogue forgot password
    if (showForgotPassword) {
        AlertDialog(
            onDismissRequest = { showForgotPassword = false },
            title = { Text("Reset Health Credentials", color = Color.White) },
            text = {
                Column {
                    Text("Enter registered email to recover clinical password.", color = Color(0xFF94A3B8), fontSize = 13.sp)
                    Spacer(modifier = Modifier.height(12.dp))
                    OutlinedTextField(
                        value = forgotEmail,
                        onValueChange = { forgotEmail = it },
                        label = { Text("Email Address") },
                        modifier = Modifier.fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = Color(0xFF0E63E5),
                            unfocusedBorderColor = Color(0xFF475569),
                            focusedTextColor = Color.White
                        )
                    )
                }
            },
            confirmButton = {
                Button(onClick = {
                    showForgotPassword = false
                    showOtpDialog = true
                }) {
                    Text("Send Recovery OTP")
                }
            },
            dismissButton = {
                TextButton(onClick = { showForgotPassword = false }) {
                    Text("Cancel")
                }
            },
            containerColor = Color(0xFF1E293B)
        )
    }

    if (showOtpDialog) {
        var otpCode by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { showOtpDialog = false },
            title = { Text("Clinical OTP Verification", color = Color.White) },
            text = {
                Column {
                    Text("We've sent a 6-digit credential verification code to $forgotEmail", color = Color(0xFF94A3B8), fontSize = 13.sp)
                    Spacer(modifier = Modifier.height(12.dp))
                    OutlinedTextField(
                        value = otpCode,
                        onValueChange = { otpCode = it },
                        label = { Text("6-Digit OTP") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = Color(0xFF0E63E5),
                            unfocusedBorderColor = Color(0xFF475569)
                        )
                    )
                }
            },
            confirmButton = {
                Button(onClick = {
                    showOtpDialog = false
                    // Force log in
                    viewModel.login(forgotEmail.ifEmpty { "demo@booknheal.com" }, "password", onSuccess = {})
                }) {
                    Text("Verify OTP & Log In")
                }
            },
            containerColor = Color(0xFF1E293B)
        )
    }
}

// ==========================================
// 4. MAIN DASHBOARD SCENE NAVIGATOR
// ==========================================
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DashboardNavigator(viewModel: BookNhealViewModel) {
    val currentTab by viewModel.currentBottomTab.collectAsStateWithLifecycle()
    val showAdmin by viewModel.showAdminDashboard.collectAsStateWithLifecycle()

    val isDarkMode by viewModel.isDarkMode.collectAsStateWithLifecycle()

    val activeDoctorDetail by viewModel.selectedDoctor.collectAsStateWithLifecycle()
    val activeConsultationDoctor by viewModel.activeConsultationDoctor.collectAsStateWithLifecycle()
    val isVideoCallActive by viewModel.isVideoCallActive.collectAsStateWithLifecycle()
    val selectedRx by viewModel.selectedPrescription.collectAsStateWithLifecycle()

    // Wrap state in material theme dynamically
    MyApplicationTheme(darkTheme = isDarkMode) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.background)
        ) {
            if (isVideoCallActive && activeConsultationDoctor != null) {
                VideoConsultationScreen(viewModel = viewModel, doctor = activeConsultationDoctor!!)
            } else if (activeDoctorDetail != null) {
                DoctorProfileScreen(viewModel = viewModel, doctor = activeDoctorDetail!!)
            } else if (selectedRx != null) {
                DigitalPrescriptionScreen(viewModel = viewModel, rx = selectedRx!!)
            } else if (showAdmin) {
                AdminDashboardScreen(viewModel = viewModel)
            } else {
                Scaffold(
                    bottomBar = {
                        NavigationBar(
                            containerColor = MaterialTheme.colorScheme.surface,
                            tonalElevation = 8.dp,
                            windowInsets = WindowInsets.navigationBars
                        ) {
                            NavigationBarItem(
                                selected = currentTab == "home",
                                onClick = { viewModel.currentBottomTab.value = "home" },
                                icon = { Icon(Icons.Default.Home, contentDescription = "Home") },
                                label = { Text("Home", fontSize = 10.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis) }
                            )
                            NavigationBarItem(
                                selected = currentTab == "appointments",
                                onClick = { viewModel.currentBottomTab.value = "appointments" },
                                icon = { Icon(Icons.Default.DateRange, contentDescription = "Appts") },
                                label = { Text("Schedules", fontSize = 10.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis) }
                            )
                            NavigationBarItem(
                                selected = currentTab == "ai_assistant",
                                onClick = { viewModel.currentBottomTab.value = "ai_assistant" },
                                icon = { Icon(Icons.Default.Face, contentDescription = "AI Companion") },
                                label = { Text("AI Assistant", fontSize = 10.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis) }
                            )
                            NavigationBarItem(
                                selected = currentTab == "notifications",
                                onClick = { viewModel.currentBottomTab.value = "notifications" },
                                icon = { Icon(Icons.Default.Notifications, contentDescription = "Alerts") },
                                label = { Text("Alerts", fontSize = 10.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis) }
                            )
                            NavigationBarItem(
                                selected = currentTab == "profile",
                                onClick = { viewModel.currentBottomTab.value = "profile" },
                                icon = { Icon(Icons.Default.Person, contentDescription = "Passport") },
                                label = { Text("Passport", fontSize = 10.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis) }
                            )
                        }
                    }
                ) { innerPadding ->
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(innerPadding)
                    ) {
                        when (currentTab) {
                            "home" -> PatientDashboardScene(viewModel = viewModel)
                            "appointments" -> AppointmentHistoryScene(viewModel = viewModel)
                            "ai_assistant" -> AiAssistantScene(viewModel = viewModel)
                            "notifications" -> NotificationsFeedScene(viewModel = viewModel)
                            "profile" -> PatientProfileScene(viewModel = viewModel)
                        }
                    }
                }
            }
        }
    }
}

// ==========================================
// 5. PATIENT DASHBOARD SCENE (TAB 1)
// ==========================================
@Composable
fun PatientDashboardScene(viewModel: BookNhealViewModel) {
    val currentUser by viewModel.currentUser.collectAsStateWithLifecycle()
    val categories = listOf("All", "Cardiologist", "Dentist", "Neurologist", "Orthopedic", "Dermatologist", "Pediatrician")
    val selectedCat by viewModel.selectedCategory.collectAsStateWithLifecycle()
    val searchQuery by viewModel.doctorSearchQuery.collectAsStateWithLifecycle()
    val filteredDocs by viewModel.filteredDoctors.collectAsStateWithLifecycle()
    val appointments by viewModel.appointments.collectAsStateWithLifecycle()

    val upcomingAppts = appointments.filter { it.status == "UPCOMING" }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp)
    ) {
        // Welcoming Card
        item {
            Spacer(modifier = Modifier.height(16.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "Hello, ${currentUser?.fullName ?: "Patient"}",
                        fontSize = 24.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = MaterialTheme.colorScheme.onBackground
                    )
                    Text(
                        text = "Smart Health Passport Token Verified",
                        fontSize = 12.sp,
                        color = Color(0xFF00B4D8),
                        fontWeight = FontWeight.Bold
                    )
                }

                // AI Avatar Pulse Indicator
                Box(
                    modifier = Modifier
                        .size(45.dp)
                        .background(Color(0xFF0E63E5).copy(alpha = 0.15f), CircleShape)
                        .clickable { viewModel.currentBottomTab.value = "ai_assistant" },
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Face,
                        contentDescription = "AI Live status",
                        tint = Color(0xFF0E63E5),
                        modifier = Modifier.size(24.dp)
                    )
                }
            }
            Spacer(modifier = Modifier.height(16.dp))
        }

        // Live Search Bar
        item {
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { viewModel.doctorSearchQuery.value = it },
                placeholder = { Text("Search doctor name, department specialty...", fontSize = 14.sp) },
                leadingIcon = { Icon(Icons.Default.Search, "Search") },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp),
                shape = RoundedCornerShape(12.dp),
                singleLine = true,
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = Color(0xFF0E63E5),
                    unfocusedBorderColor = Color(0xFF475569)
                )
            )
            Spacer(modifier = Modifier.height(14.dp))
        }

        // Hospital Department Categories horizontally
        item {
            Text(
                text = "Clinical Departments",
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onBackground
            )
            Spacer(modifier = Modifier.height(8.dp))
            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                items(categories) { cat ->
                    val isChecked = selectedCat == cat
                    Box(
                        modifier = Modifier
                            .background(
                                if (isChecked) Color(0xFF0E63E5) else Color(0xFF1E293B),
                                RoundedCornerShape(12.dp)
                            )
                            .border(1.dp, if (isChecked) Color(0xFF0E63E5) else Color(0xFF334155), RoundedCornerShape(12.dp))
                            .clickable { viewModel.selectedCategory.value = cat }
                            .padding(horizontal = 14.dp, vertical = 10.dp)
                    ) {
                        Text(
                            text = cat,
                            color = if (isChecked) Color.White else Color(0xFF94A3B8),
                            fontWeight = FontWeight.SemiBold,
                            fontSize = 13.sp
                        )
                    }
                }
            }
            Spacer(modifier = Modifier.height(16.dp))
        }

        // AI Urgent Symptom access banner
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { viewModel.currentBottomTab.value = "ai_assistant" },
                colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B)),
                shape = RoundedCornerShape(16.dp),
                border = BorderStroke(1.dp, Color(0xFF00B4D8).copy(alpha = 0.5f))
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(0.7f)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(8.dp)
                                    .background(Color(0xFF10B981), CircleShape)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "BookNheal Cognitive AI",
                                fontSize = 11.sp,
                                color = Color(0xFF10B981),
                                fontWeight = FontWeight.Bold
                            )
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "Fever, rashes, or joint sore?",
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                        Text(
                            text = "Query unified AI symptom scanner for immediate diagnostics suggestions.",
                            fontSize = 11.sp,
                            color = Color(0xFF94A3B8),
                            lineHeight = 16.sp
                        )
                    }
                    Button(
                        onClick = { viewModel.currentBottomTab.value = "ai_assistant" },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0E63E5)),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.weight(0.3f)
                    ) {
                        Text("Chat", fontSize = 12.sp, color = Color.White)
                    }
                }
            }
            Spacer(modifier = Modifier.height(16.dp))
        }

        // Upcoming Appointment alert section (If any exist)
        if (upcomingAppts.isNotEmpty()) {
            item {
                Text(
                    text = "Nearest Doctor Booking",
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onBackground
                )
                Spacer(modifier = Modifier.height(8.dp))
                upcomingAppts.take(1).forEach { apt ->
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp),
                        colors = CardDefaults.cardColors(containerColor = Color(0xFF0F172A).copy(alpha = 0.5f)),
                        shape = RoundedCornerShape(16.dp),
                        border = BorderStroke(1.dp, Color(0xFF0E63E5).copy(alpha = 0.4f))
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(14.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(45.dp)
                                    .background(Color(0xFF0E63E5).copy(alpha = 0.15f), CircleShape),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(Icons.Default.DateRange, "Schedule Active", tint = Color(0xFF0E63E5))
                            }
                            Spacer(modifier = Modifier.width(14.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(apt.doctorName, fontWeight = FontWeight.Bold, color = Color.White, fontSize = 14.sp)
                                Text(apt.specialty, fontSize = 11.sp, color = Color(0xFF00B4D8))
                                Text(apt.dateTime, fontSize = 11.sp, color = Color(0xFF94A3B8))
                            }
                            Button(
                                onClick = {
                                    // Start a virtual consultation
                                    viewModel.doctors.value.firstOrNull { it.id == apt.doctorId }?.let {
                                        viewModel.startVideoConsultation(it)
                                    } ?: run {
                                        // Fallback dummy
                                        viewModel.startVideoConsultation(
                                            DoctorEntity(apt.doctorId, apt.doctorName, apt.specialty, 10, 4.8, "Active", apt.feePaid, "Consultant", "MD", "sarah")
                                        )
                                    }
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF10B981)),
                                shape = RoundedCornerShape(8.dp),
                                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                            ) {
                                Icon(Icons.Default.PlayArrow, "Video", tint = Color.White, modifier = Modifier.size(14.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Online Call", fontSize = 11.sp, color = Color.White)
                            }
                        }
                    }
                }
                Spacer(modifier = Modifier.height(16.dp))
            }
        }

        // Daily Tips / Health metrics slider simulation
        item {
            Text(
                text = "Clinical Tips & Daily Wellness",
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onBackground
            )
            Spacer(modifier = Modifier.height(8.dp))
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF020617)),
                shape = RoundedCornerShape(16.dp),
                border = BorderStroke(1.dp, Color(0xFF334155))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("Daily Cardiovascular Tip", color = Color(0xFF00B4D8), fontWeight = FontWeight.ExtraBold, fontSize = 12.sp)
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Reduce daily processed sodium levels to under 2,300mg to alleviate dynamic arterial wall pressure. Regular hydration reduces vascular stress thresholds consistently.",
                        fontSize = 13.sp,
                        color = Color(0xFFE2E8F0),
                        lineHeight = 18.sp
                    )
                }
            }
            Spacer(modifier = Modifier.height(16.dp))
        }

        // Main Doctor Listing Cards
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Medical Specialist Team (${filteredDocs.size})",
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onBackground
                )
                if (searchQuery.isNotEmpty() || selectedCat != "All") {
                    TextButton(onClick = {
                        viewModel.doctorSearchQuery.value = ""
                        viewModel.selectedCategory.value = "All"
                    }) {
                        Text("Reset Filter", fontSize = 12.sp, color = Color(0xFF00B4D8))
                    }
                }
            }
            Spacer(modifier = Modifier.height(8.dp))
            if (filteredDocs.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(24.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text("No clinical specialists found matching filters.", color = Color(0xFF94A3B8), textAlign = TextAlign.Center)
                }
            }
        }

        items(filteredDocs) { doc ->
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 6.dp)
                    .clickable { viewModel.selectedDoctor.value = doc },
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                shape = RoundedCornerShape(16.dp),
                border = BorderStroke(1.dp, Color(0xFF475569).copy(alpha = 0.3f))
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Profile Placeholder Image with matching specialist symbol
                    Box(
                        modifier = Modifier
                            .size(60.dp)
                            .background(
                                Brush.verticalGradient(
                                    colors = listOf(Color(0xFF0E63E5).copy(alpha = 0.2f), Color(0xFF00B4D8).copy(alpha = 0.1f))
                                ),
                                CircleShape
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = when (doc.specialty) {
                                "Cardiologist" -> Icons.Default.Favorite
                                "Dentist" -> Icons.Default.Face
                                "Neurologist" -> Icons.Default.Star
                                "Orthopedic" -> Icons.Default.Star
                                "Dermatologist" -> Icons.Default.Face
                                else -> Icons.Default.Person
                            },
                            contentDescription = doc.specialty,
                            tint = Color(0xFF0E63E5),
                            modifier = Modifier.size(28.dp)
                        )
                    }

                    Spacer(modifier = Modifier.width(14.dp))

                    Column(modifier = Modifier.weight(1f)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = doc.name,
                                fontWeight = FontWeight.ExtraBold,
                                fontSize = 15.sp,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            // Spark / Live rating
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Star, "Rating", tint = Color(0xFFF59E0B), modifier = Modifier.size(12.dp))
                                Text(doc.rating.toString(), fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color(0xFFF59E0B))
                            }
                        }
                        Text(doc.specialty, fontSize = 12.sp, color = Color(0xFF00B4D8), fontWeight = FontWeight.SemiBold)
                        Text("${doc.experienceYears} Years clinical practice", fontSize = 11.sp, color = Color(0xFF94A3B8))
                        
                        Spacer(modifier = Modifier.height(4.dp))
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(6.dp)
                                    .background(Color(0xFF10B981), CircleShape)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(doc.availabilityStatus, fontSize = 11.sp, color = Color(0xFF10B981), fontWeight = FontWeight.Bold)
                        }
                    }

                    Column(horizontalAlignment = Alignment.End) {
                        Text("Fee", fontSize = 10.sp, color = Color(0xFF94A3B8))
                        Text("$${doc.consultationFee.toInt()}", fontWeight = FontWeight.ExtraBold, fontSize = 18.sp, color = Color(0xFF0E63E5))
                        Spacer(modifier = Modifier.height(6.dp))
                        Icon(Icons.Default.ArrowForward, "Detail", tint = Color(0xFF00B4D8), modifier = Modifier.size(16.dp))
                    }
                }
            }
        }
        item {
            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}

// ==========================================
// 6. DOCTOR PROFILE SCREEN (DETAIL)
// ==========================================
@OptIn(ExperimentalLayoutApi::class, ExperimentalMaterial3Api::class)
@Composable
fun DoctorProfileScreen(viewModel: BookNhealViewModel, doctor: DoctorEntity) {
    var chosenDate by remember { mutableStateOf("May 29 (Fri)") }
    var chosenSlot by remember { mutableStateOf("10:30 AM") }
    var visitReason by remember { mutableStateOf("") }
    var showConfirmAnim by remember { mutableStateOf(false) }

    val dateOptions = listOf("May 29 (Fri)", "May 30 (Sat)", "May 31 (Sun)", "Jun 01 (Mon)")
    val timeOptions = listOf("09:00 AM", "10:30 AM", "01:00 PM", "03:30 PM", "05:00 PM")

    val scope = rememberCoroutineScope()

    if (showConfirmAnim) {
        // Success booking overlay dialog
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color(0xFF0F172A)),
            contentAlignment = Alignment.Center
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Icon(Icons.Default.Check, "Success", tint = Color(0xFF10B981), modifier = Modifier.size(72.dp))
                Spacer(modifier = Modifier.height(16.dp))
                Text("Appointment Confirmed!", fontWeight = FontWeight.ExtraBold, fontSize = 24.sp, color = Color.White)
                Spacer(modifier = Modifier.height(8.dp))
                Text(doctor.name, color = Color(0xFF00B4D8), fontWeight = FontWeight.Bold, fontSize = 16.sp)
                Text("$chosenDate - $chosenSlot", color = Color(0xFF94A3B8), fontSize = 14.sp)
                Spacer(modifier = Modifier.height(24.dp))
                Button(
                    onClick = {
                        showConfirmAnim = false
                        viewModel.selectedDoctor.value = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0E63E5))
                ) {
                    Text("Return to Portfolio")
                }
            }
        }
    } else {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = { Text("Consultation Calendar") },
                    navigationIcon = {
                        IconButton(onClick = { viewModel.selectedDoctor.value = null }) {
                            Icon(Icons.Default.ArrowBack, "Back")
                        }
                    }
                )
            }
        ) { innerPadding ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
                    .padding(horizontal = 16.dp)
                    .verticalScroll(rememberScrollState())
            ) {
                // Large Header
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 12.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    shape = RoundedCornerShape(20.dp),
                    border = BorderStroke(1.dp, Color(0xFF334155).copy(alpha = 0.3f))
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(70.dp)
                                .background(Color(0xFF0E63E5).copy(alpha = 0.15f), CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Default.Person, "Doctor photo", tint = Color(0xFF0E63E5), modifier = Modifier.size(36.dp))
                        }
                        Spacer(modifier = Modifier.width(16.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(doctor.name, fontWeight = FontWeight.ExtraBold, fontSize = 18.sp, color = MaterialTheme.colorScheme.onSurface)
                            Text(doctor.specialty, color = Color(0xFF00B4D8), fontWeight = FontWeight.Bold, fontSize = 13.sp)
                            Text("Quals: ${doctor.qualifications}", fontSize = 11.sp, color = Color(0xFF94A3B8))
                            Spacer(modifier = Modifier.height(4.dp))
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Star, "rating", tint = Color(0xFFF59E0B), modifier = Modifier.size(14.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("${doctor.rating} Rating  |  ${doctor.experienceYears} Years Exp", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }

                // Biography Text
                Text("Clinical Biography", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onBackground)
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 6.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B).copy(alpha = 0.4f))
                ) {
                    Text(
                        text = doctor.biography,
                        fontSize = 13.sp,
                        color = Color(0xFF94A3B8),
                        lineHeight = 20.sp,
                        modifier = Modifier.padding(12.dp)
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Date Selection
                Text("Select Consultation Date", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onBackground)
                Spacer(modifier = Modifier.height(6.dp))
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(dateOptions) { opt ->
                        val isSel = chosenDate == opt
                        Box(
                            modifier = Modifier
                                .background(
                                    if (isSel) Color(0xFF0E63E5) else Color(0xFF1E293B),
                                    RoundedCornerShape(10.dp)
                                )
                                .border(1.dp, if (isSel) Color(0xFF0E63E5) else Color(0xFF475569).copy(alpha = 0.5f), RoundedCornerShape(10.dp))
                                .clickable { chosenDate = opt }
                                .padding(horizontal = 14.dp, vertical = 10.dp)
                        ) {
                            Text(opt, color = if (isSel) Color.White else Color(0xFF94A3B8), fontSize = 13.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Time Slot grid
                Text("Select Micro Slot", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onBackground)
                Spacer(modifier = Modifier.height(6.dp))
                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                    maxItemsInEachRow = 3,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    timeOptions.forEach { slot ->
                        val isSel = chosenSlot == slot
                        Box(
                            modifier = Modifier
                                .background(
                                    if (isSel) Color(0xFF00B4D8) else Color(0xFF1E293B),
                                    RoundedCornerShape(10.dp)
                                )
                                .border(1.dp, if (isSel) Color(0xFF00B4D8) else Color(0xFF475569).copy(alpha = 0.5f), RoundedCornerShape(10.dp))
                                .clickable { chosenSlot = slot }
                                .padding(horizontal = 16.dp, vertical = 10.dp)
                        ) {
                            Text(slot, color = if (isSel) Color.White else Color(0xFF94A3B8), fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Input reason Visiting
                Text("Reason for Clinical Visit (Optional)", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onBackground)
                Spacer(modifier = Modifier.height(6.dp))
                OutlinedTextField(
                    value = visitReason,
                    onValueChange = { visitReason = it },
                    placeholder = { Text("Describe headache, prescription refills, body pain parameters...", fontSize = 13.sp) },
                    modifier = Modifier.fillMaxWidth(),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = Color(0xFF0E63E5),
                        unfocusedBorderColor = Color(0xFF475569)
                    )
                )

                Spacer(modifier = Modifier.height(24.dp))

                // Checkout Card
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 32.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B))
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("Specialist Consultation Fee", color = Color(0xFF94A3B8), fontSize = 13.sp)
                            Text("$${doctor.consultationFee.toInt()}", fontWeight = FontWeight.ExtraBold, fontSize = 16.sp, color = Color.White)
                        }
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("Transaction Tax (Unified ID)", color = Color(0xFF94A3B8), fontSize = 13.sp)
                            Text("Free", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = Color(0xFF10B981))
                        }
                        HorizontalDivider(modifier = Modifier.padding(vertical = 10.dp), color = Color(0xFF334155))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text("Cumulative Due", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                Text("Refundable 24 hrs prior", color = Color(0xFF94A3B8), fontSize = 11.sp)
                            }
                            Text("$${doctor.consultationFee.toInt()}", fontWeight = FontWeight.ExtraBold, fontSize = 20.sp, color = Color(0xFF0E63E5))
                        }
                        Spacer(modifier = Modifier.height(14.dp))
                        Button(
                            onClick = {
                                viewModel.proceedToBookAppointment(
                                    doctor,
                                    chosenDate,
                                    chosenSlot,
                                    visitReason,
                                    onSuccess = {
                                        showConfirmAnim = true
                                    }
                                )
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(50.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0E63E5)),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Text("Confirm Booking & Pay Now", fontSize = 14.sp)
                        }
                    }
                }
            }
        }
    }
}

// ==========================================
// 7. APPOINTMENT LIST / HISTORIC ARCHIVE (TAB 2)
// ==========================================
@Composable
fun AppointmentHistoryScene(viewModel: BookNhealViewModel) {
    val appointments by viewModel.appointments.collectAsStateWithLifecycle()
    val prescriptions by viewModel.prescriptions.collectAsStateWithLifecycle()

    var statusFilter by remember { mutableStateOf("UPCOMING") } // "UPCOMING", "COMPLETED", "CANCELLED"

    val listFiltered = appointments.filter { it.status == statusFilter }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Text("Clinical Appointment Ledger", fontWeight = FontWeight.ExtraBold, fontSize = 22.sp, color = MaterialTheme.colorScheme.onBackground)
        Text("Verify live telemedicine pipelines and medical logs", color = Color(0xFF00B4D8), fontSize = 11.sp)

        Spacer(modifier = Modifier.height(14.dp))

        // Ledger Status Toggles
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            val sections = listOf("UPCOMING", "COMPLETED", "CANCELLED")
            sections.forEach { section ->
                val selected = statusFilter == section
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .background(
                            if (selected) Color(0xFF0E63E5) else Color(0xFF1E293B),
                            RoundedCornerShape(8.dp)
                        )
                        .clickable { statusFilter = section }
                        .padding(vertical = 10.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        section,
                        color = if (selected) Color.White else Color(0xFF94A3B8),
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        if (listFiltered.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(Icons.Default.DateRange, "Ledger Blank", tint = Color(0xFF475569), modifier = Modifier.size(54.dp))
                    Spacer(modifier = Modifier.height(10.dp))
                    Text("No records matching '$statusFilter'", color = Color(0xFF94A3B8), fontSize = 13.sp)
                }
            }
        } else {
            LazyColumn(modifier = Modifier.weight(1f)) {
                items(listFiltered) { apt ->
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 6.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        border = BorderStroke(1.dp, Color(0xFF475569).copy(alpha = 0.25f))
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text(apt.doctorName, fontWeight = FontWeight.Bold, fontSize = 16.sp, color = MaterialTheme.colorScheme.onSurface)
                                    Text(apt.specialty, color = Color(0xFF00B4D8), fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                }
                                Box(
                                    modifier = Modifier
                                        .background(
                                            when (apt.status) {
                                                "UPCOMING" -> Color(0xFF0E63E5).copy(alpha = 0.2f)
                                                "COMPLETED" -> Color(0xFF10B981).copy(alpha = 0.2f)
                                                else -> Color(0xFFEF4444).copy(alpha = 0.2f)
                                            },
                                            RoundedCornerShape(6.dp)
                                        )
                                        .padding(horizontal = 8.dp, vertical = 4.dp)
                                ) {
                                    Text(
                                        text = apt.status,
                                        color = when (apt.status) {
                                            "UPCOMING" -> Color(0xFF3B82F6)
                                            "COMPLETED" -> Color(0xFF10B981)
                                            else -> Color(0xFFEF4444)
                                        },
                                        fontWeight = FontWeight.Black,
                                        fontSize = 11.sp
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(10.dp))

                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.DateRange, "Date", tint = Color(0xFF94A3B8), modifier = Modifier.size(14.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(apt.dateTime, color = Color(0xFF94A3B8), fontSize = 12.sp)
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            Text("Reason: ${apt.reasonForVisit}", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurface)

                            Spacer(modifier = Modifier.height(14.dp))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.End,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                if (apt.status == "UPCOMING") {
                                    TextButton(onClick = {
                                        viewModel.changeAppointmentStatus(apt.id, "CANCELLED")
                                    }) {
                                        Text("Cancel", color = Color(0xFFEF4444))
                                    }
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Button(
                                        onClick = {
                                            viewModel.changeAppointmentStatus(apt.id, "COMPLETED")
                                        },
                                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF10B981))
                                    ) {
                                        Text("Consult Sim Complete", fontSize = 11.sp, color = Color.White)
                                    }
                                } else if (apt.status == "COMPLETED") {
                                    val matchRx = prescriptions.firstOrNull { it.appointmentId == apt.id }
                                    if (matchRx != null) {
                                        Button(
                                            onClick = {
                                                viewModel.selectedPrescription.value = matchRx
                                            },
                                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0E63E5))
                                        ) {
                                            Text("Open Digital Rx", fontSize = 11.sp, color = Color.White)
                                        }
                                    } else {
                                        Text("No Prescription Found", color = Color(0xFF94A3B8), fontSize = 11.sp)
                                    }
                                } else {
                                    // Cancelled
                                    TextButton(onClick = {
                                        viewModel.proceedToBookAppointment(
                                            DoctorEntity(apt.doctorId, apt.doctorName, apt.specialty, 10, 4.8, "Active", apt.feePaid, "Consultant", "MD", "sarah"),
                                            "May 30 (Sat)",
                                            "11:00 AM",
                                            "Re-booking cancelled specialist slot",
                                            onSuccess = {}
                                        )
                                    }) {
                                        Text("Rebook Slot", color = Color(0xFF00B4D8))
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

// ==========================================
// 8. AI HEALTH ASSISTANT SCENE (TAB 3)
// ==========================================
@Composable
fun AiAssistantScene(viewModel: BookNhealViewModel) {
    val messages = viewModel.chatMessages
    val isThinking by viewModel.isAiThinking.collectAsStateWithLifecycle()

    var userText by remember { mutableStateOf("") }
    val keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Text)

    val samplePrompts = listOf(
        "I have fever and head sore",
        "Recommended joint support clinics?",
        "Tips for clinical migraine relief?"
    )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        // Applet Banner
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(40.dp)
                    .background(Color(0xFF0E63E5).copy(alpha = 0.2f), CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(Icons.Default.Face, "AI Avatar", tint = Color(0xFF0E63E5), modifier = Modifier.size(24.dp))
            }
            Spacer(modifier = Modifier.width(12.dp))
            Column {
                Text(
                    text = "BookNheal AI Doctor-Advisor",
                    fontWeight = FontWeight.ExtraBold,
                    fontSize = 16.sp,
                    color = MaterialTheme.colorScheme.onBackground
                )
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(modifier = Modifier.size(6.dp).background(Color(0xFF10B981), CircleShape))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Powered by Gemini 3.5 Flash", fontSize = 10.sp, color = Color(0xFF10B981), fontWeight = FontWeight.Bold)
                }
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Suggestion Chips
        LazyRow(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            items(samplePrompts) { chip ->
                Box(
                    modifier = Modifier
                        .background(Color(0xFF1E293B), RoundedCornerShape(10.dp))
                        .border(1.dp, Color(0xFF334155), RoundedCornerShape(10.dp))
                        .clickable { viewModel.submitSuggestedPrompt(chip) }
                        .padding(horizontal = 12.dp, vertical = 8.dp)
                ) {
                    Text(chip, color = Color(0xFFE2E8F0), fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                }
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Messages scrolling view
        LazyColumn(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(10.dp),
            reverseLayout = false
        ) {
            items(messages) { msg ->
                val isUsr = msg.isUser
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = if (isUsr) Arrangement.End else Arrangement.Start
                ) {
                    Card(
                        modifier = Modifier.fillMaxWidth(0.85f),
                        colors = CardDefaults.cardColors(
                            containerColor = if (isUsr) Color(0xFF0E63E5) else Color(0xFF1E293B)
                        ),
                        shape = RoundedCornerShape(
                            topStart = 16.dp,
                            topEnd = 16.dp,
                            bottomStart = if (isUsr) 16.dp else 0.dp,
                            bottomEnd = if (isUsr) 0.dp else 16.dp
                        )
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Text(
                                text = if (isUsr) "You" else "AI Diagnostics",
                                fontWeight = FontWeight.Black,
                                fontSize = 11.sp,
                                color = if (isUsr) Color.White.copy(alpha = 0.8f) else Color(0xFF00B4D8)
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = msg.text,
                                color = Color.White,
                                fontSize = 13.sp,
                                lineHeight = 19.sp
                            )
                        }
                    }
                }
            }

            if (isThinking) {
                item {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.Start
                    ) {
                        Card(
                            colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B)),
                            shape = RoundedCornerShape(16.dp)
                        ) {
                            Row(
                                modifier = Modifier.padding(12.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                CircularProgressIndicator(color = Color(0xFF00B4D8), modifier = Modifier.size(16.dp), strokeWidth = 2.dp)
                                Spacer(modifier = Modifier.width(10.dp))
                                Text("Synthesizing response...", color = Color(0xFF94A3B8), fontSize = 12.sp)
                            }
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Input bottom bar
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            OutlinedTextField(
                value = userText,
                onValueChange = { userText = it },
                placeholder = { Text("Query symptoms (fever, migraine)...", fontSize = 13.sp) },
                modifier = Modifier.weight(1f),
                singleLine = true,
                keyboardOptions = keyboardOptions,
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = Color(0xFF0E63E5),
                    unfocusedBorderColor = Color(0xFF475569)
                )
            )

            Spacer(modifier = Modifier.width(8.dp))

            IconButton(
                onClick = {
                    if (userText.trim().isNotEmpty()) {
                        viewModel.sendUserMessage(userText)
                        userText = ""
                    }
                },
                modifier = Modifier
                    .size(48.dp)
                    .background(Color(0xFF0E63E5), CircleShape)
            ) {
                Icon(Icons.Default.ArrowForward, "Send", tint = Color.White)
            }
        }
    }
}

// ==========================================
// 9. THE NOTIFICATIONS FEED SCENE (TAB 4)
// ==========================================
@Composable
fun NotificationsFeedScene(viewModel: BookNhealViewModel) {
    val notes by viewModel.notifications.collectAsStateWithLifecycle()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text("Health Alerts Desk", fontWeight = FontWeight.ExtraBold, fontSize = 22.sp, color = MaterialTheme.colorScheme.onBackground)
                Text("Verify unified clinical suggestions and system signals", color = Color(0xFF00B4D8), fontSize = 11.sp)
            }

            TextButton(onClick = { viewModel.clearAllNotifications() }) {
                Text("Mark All Read", color = Color(0xFF0E63E5), fontSize = 13.sp)
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        if (notes.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                contentAlignment = Alignment.Center
            ) {
                Text("Clear feed. All healthcare structures are operational.", color = Color(0xFF475569))
            }
        } else {
            LazyColumn(modifier = Modifier.weight(1f)) {
                items(notes) { note ->
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 5.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = if (note.isRead) MaterialTheme.colorScheme.surface.copy(alpha = 0.5f) else MaterialTheme.colorScheme.surface
                        ),
                        border = BorderStroke(1.dp, Color(0xFF475569).copy(alpha = 0.2f))
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(36.dp)
                                    .background(
                                        when (note.type) {
                                            "REMINDER" -> Color(0xFFEF4444).copy(alpha = 0.15f)
                                            "TIPS" -> Color(0xFFF59E0B).copy(alpha = 0.15f)
                                            "AI" -> Color(0xFF10B981).copy(alpha = 0.15f)
                                            else -> Color(0xFF3B82F6).copy(alpha = 0.15f)
                                        },
                                        CircleShape
                                    ),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = when (note.type) {
                                        "REMINDER" -> Icons.Default.DateRange
                                        "TIPS" -> Icons.Default.Info
                                        "AI" -> Icons.Default.Face
                                        else -> Icons.Default.Notifications
                                    },
                                    contentDescription = note.type,
                                    tint = when (note.type) {
                                        "REMINDER" -> Color(0xFFEF4444)
                                        "TIPS" -> Color(0xFFF59E0B)
                                        "AI" -> Color(0xFF10B981)
                                        else -> Color(0xFF3B82F6)
                                    }
                                )
                            }

                            Spacer(modifier = Modifier.width(12.dp))

                            Column(modifier = Modifier.weight(1f)) {
                                Text(note.title, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface, fontSize = 13.sp)
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(note.content, color = Color(0xFF94A3B8), fontSize = 12.sp, lineHeight = 16.sp)
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(note.timestamp, color = Color(0xFF475569), fontSize = 10.sp)
                            }
                        }
                    }
                }
            }
        }
    }
}

// ==========================================
// 10. PATIENT HEALTH PASSPORT / PROFILE SCENE (TAB 5)
// ==========================================
@Composable
fun PatientProfileScene(viewModel: BookNhealViewModel) {
    val currentUser by viewModel.currentUser.collectAsStateWithLifecycle()

    var historyInput by remember { mutableStateOf(currentUser?.medicalHistory ?: "") }
    var emergencyInput by remember { mutableStateOf(currentUser?.emergencyContact ?: "") }
    var insuranceInput by remember { mutableStateOf(currentUser?.insuranceNumber ?: "") }

    var isEditMode by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
            .verticalScroll(rememberScrollState())
    ) {
        // User Details Card
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B))
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Box(
                    modifier = Modifier
                        .size(65.dp)
                        .background(Color(0xFF0E63E5), CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = currentUser?.fullName?.take(2)?.uppercase() ?: "PT",
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 24.sp
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                Text(currentUser?.fullName ?: "DemPatient", fontWeight = FontWeight.ExtraBold, fontSize = 18.sp, color = Color.White)
                Text(currentUser?.email ?: "demopatient@gmail.com", color = Color(0xFF00B4D8), fontSize = 13.sp)
                Text("Verified Global ID: BNH-${currentUser?.fullName.hashCode().coerceAtLeast(1000)}", color = Color(0xFF94A3B8), fontSize = 11.sp)
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Medical passport section
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("Health Passport Metrics", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = MaterialTheme.colorScheme.onBackground)
            TextButton(onClick = {
                if (isEditMode) {
                    viewModel.updateMedicalProfile(historyInput, emergencyInput, insuranceInput)
                }
                isEditMode = !isEditMode
            }) {
                Text(if (isEditMode) "Save Changes" else "Edit Passport", color = Color(0xFF0E63E5))
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        if (isEditMode) {
            OutlinedTextField(
                value = historyInput,
                onValueChange = { historyInput = it },
                label = { Text("Clinical History Parameter") },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = Color(0xFF0E63E5),
                    unfocusedBorderColor = Color(0xFF475569)
                )
            )

            OutlinedTextField(
                value = emergencyInput,
                onValueChange = { emergencyInput = it },
                label = { Text("Emergency Contact Coordinate") },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = Color(0xFF0E63E5),
                    unfocusedBorderColor = Color(0xFF475569)
                )
            )

            OutlinedTextField(
                value = insuranceInput,
                onValueChange = { insuranceInput = it },
                label = { Text("National Health Insurance Ref") },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = Color(0xFF0E63E5),
                    unfocusedBorderColor = Color(0xFF475569)
                )
            )
        } else {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, Color(0xFF334155).copy(alpha = 0.25f))
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text("Clinical Bio History", color = Color(0xFF00B4D8), fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    Text(currentUser?.medicalHistory ?: "No major diagnostic incidents indexed.", color = MaterialTheme.colorScheme.onSurface, fontSize = 14.sp)
                    
                    Spacer(modifier = Modifier.height(12.dp))
                    
                    Text("Emergency Contact Node", color = Color(0xFF00B4D8), fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    Text(currentUser?.emergencyContact ?: "None", color = MaterialTheme.colorScheme.onSurface, fontSize = 14.sp)
                    
                    Spacer(modifier = Modifier.height(12.dp))
                    
                    Text("Insurance Number Token", color = Color(0xFF00B4D8), fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    Text(currentUser?.insuranceNumber ?: "INS-TEMP-9988-X", color = MaterialTheme.colorScheme.onSurface, fontSize = 14.sp)
                }
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // Hospital Admin Dashboard Launcher button
        Button(
            onClick = { viewModel.showAdminDashboard.value = true },
            modifier = Modifier
                .fillMaxWidth()
                .height(48.dp),
            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1E293B)),
            shape = RoundedCornerShape(12.dp),
            border = BorderStroke(1.dp, Color(0xFF475569))
        ) {
            Icon(Icons.Default.Settings, "Admin", tint = Color(0xFF00B4D8))
            Spacer(modifier = Modifier.width(10.dp))
            Text("Open Hospital Admin Portal", color = Color.White)
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Safe sign out
        Button(
            onClick = { viewModel.logout() },
            modifier = Modifier
                .fillMaxWidth()
                .height(48.dp),
            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFEF4444).copy(alpha = 0.15f)),
            shape = RoundedCornerShape(12.dp)
        ) {
            Icon(Icons.Default.Close, "Logout", tint = Color(0xFFEF4444))
            Spacer(modifier = Modifier.width(10.dp))
            Text("Disconnect Secure health Session", color = Color(0xFFEF4444))
        }

        Spacer(modifier = Modifier.height(20.dp))
    }
}

// ==========================================
// 11. VIDEO TELEMEDICINE SIMULATION SCREEN
// ==========================================
@Composable
fun VideoConsultationScreen(viewModel: BookNhealViewModel, doctor: DoctorEntity) {
    val isMuted by viewModel.isMicMuted.collectAsStateWithLifecycle()
    val isCamOff by viewModel.isCameraOff.collectAsStateWithLifecycle()

    var mockChatText by remember { mutableStateOf("") }
    var mockIncomingSubtitle by remember { mutableStateOf("Clinical connection finalized. Video telemetry active.") }
    val chatScrollState = rememberScrollState()

    // Trigger funny medical subtitles automatically during active telemedicine call
    LaunchedEffect(Unit) {
        val subtitles = listOf(
            "Dr. Specialist: Can you rotate the forearm region towards target camera light?",
            "Dr. Specialist: Deep breathe in and hold steady. Perfect.",
            "Dr. Specialist: Your cardiac records are locked in. I will synthesize the prescription.",
            "Clinical pipeline encrypted safely end-to-end."
        )
        subtitles.forEach { sub ->
            delay(5000)
            mockIncomingSubtitle = sub
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF020617))
    ) {
        // Full background representation of Doctor call stream (Animated canvas heart pulse)
        Column(
            modifier = Modifier.fillMaxSize(),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            if (isCamOff) {
                Box(
                    modifier = Modifier
                        .size(120.dp)
                        .background(Color(0xFF0E63E5).copy(alpha = 0.2f), CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        doctor.name.take(2).uppercase(),
                        fontWeight = FontWeight.Bold,
                        color = Color.White,
                        fontSize = 32.sp
                    )
                }
            } else {
                // Interactive clinical graphics indicating call status
                Box(contentAlignment = Alignment.Center) {
                    Text(
                        "Clinical Call Feed: ${doctor.name}",
                        color = Color.White,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            Text(doctor.name, fontWeight = FontWeight.Bold, color = Color.White, fontSize = 20.sp)
            Text(doctor.specialty, color = Color(0xFF00B4D8), fontSize = 13.sp)

            Spacer(modifier = Modifier.height(16.dp))

            // Pulse wave
            Box(
                modifier = Modifier
                    .fillMaxWidth(0.8f)
                    .height(60.dp)
                    .background(Color(0xFF1E293B), RoundedCornerShape(12.dp))
            ) {
                Text(
                    text = mockIncomingSubtitle,
                    fontSize = 11.sp,
                    color = Color(0xFF10B981),
                    modifier = Modifier
                        .padding(12.dp)
                        .align(Alignment.Center),
                    textAlign = TextAlign.Center
                )
            }
        }

        // Mini float overlay: Patient camera stream placeholder
        Box(
            modifier = Modifier
                .padding(24.dp)
                .size(width = 110.dp, height = 150.dp)
                .background(Color(0xFF1E293B), RoundedCornerShape(12.dp))
                .border(2.dp, Color(0xFF00B4D8), RoundedCornerShape(12.dp))
                .align(Alignment.TopEnd),
            contentAlignment = Alignment.Center
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Icon(Icons.Default.Person, "Patient Screen", tint = Color.White)
                Spacer(modifier = Modifier.height(4.dp))
                Text("Demo Patient", color = Color.White, fontSize = 11.sp)
                Text("Self Camera Feed", color = Color(0xFF94A3B8), fontSize = 8.sp)
            }
        }

        // Top left back exit button
        IconButton(
            onClick = { viewModel.endVideoConsultation() },
            modifier = Modifier
                .padding(24.dp)
                .background(Color.Black.copy(alpha = 0.5f), CircleShape)
                .align(Alignment.TopStart)
        ) {
            Icon(Icons.Default.ArrowBack, "End", tint = Color.White)
        }

        // Telemedicine calling console controls overlay on bottom
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
                .align(Alignment.BottomCenter),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF0F172A))
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(12.dp),
                horizontalArrangement = Arrangement.SpaceAround,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Mic check toggle
                IconButton(
                    onClick = { viewModel.isMicMuted.value = !isMuted },
                    modifier = Modifier.background(if (isMuted) Color(0xFFEF4444) else Color(0xFF334155), CircleShape)
                ) {
                    Icon(Icons.Default.Check, "Mute", tint = Color.White)
                }

                // Camera check toggle
                IconButton(
                    onClick = { viewModel.isCameraOff.value = !isCamOff },
                    modifier = Modifier.background(if (isCamOff) Color(0xFFEF4444) else Color(0xFF334155), CircleShape)
                ) {
                    Icon(Icons.Default.Face, "Cam", tint = Color.White)
                }

                // RED exit call button
                Button(
                    onClick = { viewModel.endVideoConsultation() },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFEF4444)),
                    shape = CircleShape,
                    modifier = Modifier.size(54.dp)
                ) {
                    Icon(Icons.Default.Close, "End Consultation", tint = Color.White)
                }
            }
        }
    }
}

// ==========================================
// 12. DIGITAL ALGORITHM PRESCRIPTION SCREEN
// ==========================================
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DigitalPrescriptionScreen(viewModel: BookNhealViewModel, rx: PrescriptionEntity) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Clinical Digital Prescription") },
                navigationIcon = {
                    IconButton(onClick = { viewModel.selectedPrescription.value = null }) {
                        Icon(Icons.Default.ArrowBack, "Back")
                    }
                }
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(16.dp)
                .verticalScroll(rememberScrollState()),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Document background layout representation
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 20.dp)
                    .shadow(8.dp, RoundedCornerShape(16.dp)),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                shape = RoundedCornerShape(16.dp),
                border = BorderStroke(1.dp, Color(0xFF0E63E5).copy(alpha = 0.3f))
            ) {
                Column(modifier = Modifier.padding(20.dp)) {
                    // Hospital Seal / Token Row
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text("BookNheal Clinical Hub", fontWeight = FontWeight.Bold, color = Color(0xFF0E63E5), fontSize = 16.sp)
                            Text("Newtogen Health Platform", color = Color(0xFF94A3B8), fontSize = 10.sp)
                        }
                        Icon(Icons.Default.Favorite, "Heart Symbol", tint = Color(0xFFEF4444), modifier = Modifier.size(24.dp))
                    }

                    Spacer(modifier = Modifier.height(10.dp))
                    HorizontalDivider(color = Color(0xFF334155).copy(alpha = 0.5f))
                    Spacer(modifier = Modifier.height(12.dp))

                    // Patient and Doctor Details
                    Row(modifier = Modifier.fillMaxWidth()) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("PHYSICIAN SPECIALIST", color = Color(0xFF00B4D8), fontWeight = FontWeight.Bold, fontSize = 10.sp)
                            Text(rx.doctorName, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        }
                        Column(modifier = Modifier.weight(1f)) {
                            Text("CONSULTATION DATE", color = Color(0xFF00B4D8), fontWeight = FontWeight.Bold, fontSize = 10.sp)
                            Text(rx.date, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // Rx Items list
                    Text("MEDICATION FORM WORKSHOP (Rx)", color = Color(0xFF0E63E5), fontWeight = FontWeight.Bold, fontSize = 11.sp)
                    Spacer(modifier = Modifier.height(6.dp))
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(Color(0xFF1E293B).copy(alpha = 0.4f), RoundedCornerShape(10.dp))
                            .padding(12.dp)
                    ) {
                        Text(
                            text = rx.medicineListJson,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Medium,
                            lineHeight = 22.sp
                        )
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // Dosage notes & clinical guidance
                    Text("SPECIFIC INGESTION METRICS", color = Color(0xFF00B4D8), fontWeight = FontWeight.Bold, fontSize = 11.sp)
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(rx.dosageNotes, fontSize = 12.sp, fontWeight = FontWeight.Normal)

                    Spacer(modifier = Modifier.height(14.dp))

                    Text("SPECIALIST CLINICAL ADVICE", color = Color(0xFF00B4D8), fontWeight = FontWeight.Bold, fontSize = 11.sp)
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(rx.doctorNotes, fontSize = 12.sp, fontStyle = androidx.compose.ui.text.font.FontStyle.Italic)

                    Spacer(modifier = Modifier.height(24.dp))

                    // QR and Stamp
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text("DIGITAL SECURITY VERIFIED", color = Color(0xFF10B981), fontWeight = FontWeight.Black, fontSize = 10.sp)
                            Text("Ref Code: BNH-RX-${rx.id * 1872}-OK", color = Color(0xFF94A3B8), fontSize = 10.sp)
                        }
                        Box(
                            modifier = Modifier
                                .size(45.dp)
                                .background(Color.White)
                                .border(1.dp, Color(0xFF475569)),
                            contentAlignment = Alignment.Center
                        ) {
                            // Represent QR Code
                            Icon(Icons.Default.ArrowForward, "Secure Stamp", tint = Color.Black)
                        }
                    }
                }
            }

            // Downloader mock button
            Button(
                onClick = {
                    // Download PDF code triggers
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(50.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF10B981))
            ) {
                Text("Download Verified PDF copy", color = Color.White)
            }
        }
    }
}

// ==========================================
// 13. ADMINISTRATION CONTROL DESK (INSIGHT PANEL)
// ==========================================
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AdminDashboardScreen(viewModel: BookNhealViewModel) {
    val appointments by viewModel.appointments.collectAsStateWithLifecycle()
    val doctors by viewModel.doctors.collectAsStateWithLifecycle()

    val totalAppointments = appointments.size
    val totalRevenue = appointments.sumOf { it.feePaid }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("BookNheal Hospital Admin Console") },
                navigationIcon = {
                    IconButton(onClick = { viewModel.showAdminDashboard.value = false }) {
                        Icon(Icons.Default.ArrowBack, "Back")
                    }
                }
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(16.dp)
                .verticalScroll(rememberScrollState())
        ) {
            Text("Cumulative Analytics Ecosystem", fontWeight = FontWeight.ExtraBold, fontSize = 18.sp)
            Text("Operations manager metrics for Newtogen Private Limited integration.", color = Color(0xFF00B4D8), fontSize = 11.sp)

            Spacer(modifier = Modifier.height(16.dp))

            // Stat Cards
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Card(
                    modifier = Modifier.weight(1f),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF1D4ED8))
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Text("Cumulative Slots", color = Color.White.copy(alpha = 0.7f), fontSize = 11.sp)
                        Text(totalAppointments.toString(), color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Bold)
                    }
                }

                Card(
                    modifier = Modifier.weight(1f),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF065F46))
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Text("Hospital Revenue", color = Color.White.copy(alpha = 0.7f), fontSize = 11.sp)
                        Text("$${totalRevenue.toInt()}", color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Custom Analytics Canvas bar chart visualization (No web components, fully native!)
            Text("Operational Specialty Allocations", fontWeight = FontWeight.Bold, fontSize = 14.sp)
            Spacer(modifier = Modifier.height(8.dp))
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    val allocations = listOf("Cardio" to 0.4f, "Dental" to 0.25f, "Neuro" to 0.15f, "Derm" to 0.2f)
                    allocations.forEach { (label, pct) ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(label, color = Color(0xFFE2E8F0), modifier = Modifier.weight(0.3f), fontSize = 12.sp)
                            Box(
                                modifier = Modifier
                                    .weight(0.7f)
                                    .height(10.dp)
                                    .background(Color(0xFF334155), RoundedCornerShape(5.dp))
                            ) {
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth(pct)
                                        .fillMaxHeight()
                                        .background(Color(0xFF0E63E5), RoundedCornerShape(5.dp))
                                )
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Active physician ledger table list
            Text("Hospital Physicians (${doctors.size})", fontWeight = FontWeight.Bold, fontSize = 14.sp)
            Spacer(modifier = Modifier.height(8.dp))
            doctors.forEach { doc ->
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderStroke(1.dp, Color(0xFF334155).copy(alpha = 0.2f))
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(doc.name, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                            Text(doc.specialty, color = Color(0xFF00B4D8), fontSize = 11.sp)
                        }

                        Box(
                            modifier = Modifier
                                .background(Color(0xFF10B981).copy(alpha = 0.2f), RoundedCornerShape(4.dp))
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Text("Operational", color = Color(0xFF10B981), fontSize = 10.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }
}
