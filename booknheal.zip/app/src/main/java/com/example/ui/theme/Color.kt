package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val MedicalBluePrimary = Color(0xFF0E63E5)
val SoftCyanSecondary = Color(0xFF00B4D8)
val WarmAccentGold = Color(0xFFF59E0B)

val MedicalMintGreen = Color(0xFF10B981)
val MedicalDeepSlate = Color(0xFF111827)
val CardSlateDark = Color(0xFF1F2937)

val DarkSurfaceBackground = Color(0xFF0B0F19)
val LightSurfaceBackground = Color(0xFFF9FAFB)

val Purple80 = Color(0xFFD0BCFF)
val PurpleGrey80 = Color(0xFFCCC2DC)
val Pink80 = Color(0xFFEFB8C8)

val Purple40 = Color(0xFF6650a4)
val PurpleGrey40 = Color(0xFF625b71)
val Pink40 = Color(0xFF7D5260)
