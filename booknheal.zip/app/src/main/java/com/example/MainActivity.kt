package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.lifecycle.ViewModelProvider
import com.example.ui.BookNhealApp
import com.example.viewmodel.BookNhealViewModel

class MainActivity : ComponentActivity() {
  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    enableEdgeToEdge()
    
    // Obtain viewmodel safely
    val viewModel = ViewModelProvider(this)[BookNhealViewModel::class.java]

    setContent {
      BookNhealApp(viewModel = viewModel)
    }
  }
}
