package com.example.viewmodel

import android.app.Application
import android.util.Log
import androidx.compose.runtime.mutableStateListOf
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

class BookNhealViewModel(application: Application) : AndroidViewModel(application) {

    private val db = BookNhealDatabase.getInstance(application)
    private val userDao = db.userDao
    private val doctorDao = db.doctorDao
    private val appointmentDao = db.appointmentDao
    private val prescriptionDao = db.prescriptionDao
    private val notificationDao = db.notificationDao

    // --- Dynamic Dark Theme ---
    val isDarkMode = MutableStateFlow(true)

    // --- Onboarding & Auth States ---
    val isOnboarded = MutableStateFlow(false)
    val currentUser = MutableStateFlow<UserEntity?>(null)
    val isAuthLoading = MutableStateFlow(false)
    val authError = MutableStateFlow<String?>(null)

    // --- Active App Navigation States ---
    val currentBottomTab = MutableStateFlow("home") // "home", "appointments", "ai_assistant", "notifications", "profile"
    val showAdminDashboard = MutableStateFlow(false)

    // --- Database Flow Feeds ---
    val doctors: StateFlow<List<DoctorEntity>> = doctorDao.getAllDoctorsFlow()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val appointments: StateFlow<List<AppointmentEntity>> = appointmentDao.getAllAppointmentsFlow()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val prescriptions: StateFlow<List<PrescriptionEntity>> = prescriptionDao.getAllPrescriptionsFlow()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val notifications: StateFlow<List<NotificationEntity>> = notificationDao.getAllNotificationsFlow()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // --- Doctor Filtration State ---
    val selectedCategory = MutableStateFlow("All")
    val doctorSearchQuery = MutableStateFlow("")

    val filteredDoctors = MutableStateFlow<List<DoctorEntity>>(emptyList())

    // --- Selected Doctor Details ---
    val selectedDoctor = MutableStateFlow<DoctorEntity?>(null)

    // --- Booking Active Flow State ---
    val appointmentDate = MutableStateFlow("")
    val appointmentTimeSlot = MutableStateFlow("")
    val appointmentReason = MutableStateFlow("")
    val bookingSuccessReceipt = MutableStateFlow<AppointmentEntity?>(null)

    // --- AI Chat History ---
    data class ChatMessage(val text: String, val isUser: Boolean, val timestamp: Long = System.currentTimeMillis())
    val chatMessages = mutableStateListOf<ChatMessage>()
    val isAiThinking = MutableStateFlow(false)

    // --- Video Consultation Simulation ---
    val activeConsultationDoctor = MutableStateFlow<DoctorEntity?>(null)
    val isVideoCallActive = MutableStateFlow(false)
    val isMicMuted = MutableStateFlow(false)
    val isCameraOff = MutableStateFlow(false)

    // --- Selected Prescription ---
    val selectedPrescription = MutableStateFlow<PrescriptionEntity?>(null)

    init {
        // Build initial seed data and set up default state
        viewModelScope.launch {
            seedInitialDatabase()
            chatMessages.add(ChatMessage("Hello! I am your AI Health Companion under BookNheal. Please feel free to tell me your symptoms, ask health-related questions, or query our hospital facilities.", false))
            
            // Watch lists for search/filter logic
            launch {
                doctors.collect { list ->
                    filterDoctorsList(list, selectedCategory.value, doctorSearchQuery.value)
                }
            }
            launch {
                selectedCategory.collect { category ->
                    filterDoctorsList(doctors.value, category, doctorSearchQuery.value)
                }
            }
            launch {
                doctorSearchQuery.collect { query ->
                    filterDoctorsList(doctors.value, selectedCategory.value, query)
                }
            }
        }
    }

    private fun filterDoctorsList(all: List<DoctorEntity>, category: String, query: String) {
        var result = all
        if (category != "All") {
            result = result.filter { it.specialty.lowercase() == category.lowercase() }
        }
        if (query.isNotEmpty()) {
            result = result.filter { 
                it.name.contains(query, ignoreCase = true) || 
                it.specialty.contains(query, ignoreCase = true) 
            }
        }
        filteredDoctors.value = result
    }

    private suspend fun seedInitialDatabase() {
        // Seeding Doctors if empty
        if (doctorDao.getDoctorCount() == 0) {
            val seedDoctors = listOf(
                DoctorEntity(
                    "doc1", "Dr. Sarah Jenkins", "Cardiologist", 12, 4.9, "Available", 150.0,
                    "Senior Cardiology Specialist with interests in preventive cardiology, heart failures, and non-invasive diagnosis techniques.",
                    "MD, FACC - Harvard Medical School", "sarah"
                ),
                DoctorEntity(
                    "doc2", "Dr. Michael Chang", "Dentist", 8, 4.8, "Available Today", 80.0,
                    "Expert in root canals, painless extractions, and cosmetic veneers with a focus on comfortable dental environments.",
                    "DDS - Boston University Dental College", "michael"
                ),
                DoctorEntity(
                    "doc3", "Dr. Elena Rostova", "Neurologist", 15, 4.9, "Available Tomorrow", 200.0,
                    "Renowned neurologist specializing in neural micro-remediations, chronic migraine relief, and neuropathy.",
                    "MD, Ph.D. - Johns Hopkins University", "elena"
                ),
                DoctorEntity(
                    "doc4", "Dr. Marcus Vance", "Orthopedic", 10, 4.7, "Available Tomorrow", 120.0,
                    "Orthopedic surgeon focused on robotic joint replacements, sports injuries, and advanced reconstructive arthrosurgery.",
                    "MD - Stanford Medical School", "marcus"
                ),
                DoctorEntity(
                    "doc5", "Dr. Amara Patel", "Dermatologist", 9, 4.8, "Available Today", 90.0,
                    "Award-winning clinical and aesthetic dermatologist specializing in skin rejuvenation, acne solutions, and early detection screens.",
                    "MD - Mayo Clinic Graduate School", "amara"
                ),
                DoctorEntity(
                    "doc6", "Dr. Robert Fletcher", "Pediatrician", 14, 4.9, "Available Today", 100.0,
                    "Compassionate, kid-friendly general pediatrician specializing in child behavioral systems, immunity patterns, and growth tracking.",
                    "MD, FAAP - Yale Pediatric Residence", "robert"
                )
            )
            doctorDao.insertDoctors(seedDoctors)
            Log.d("BookNhealViewModel", "Doctors collection seeded successfully.")

            // Seed Some Default Completed Appointments & Prescriptions for the default user
            val appointmentId1 = appointmentDao.insertAppointment(
                AppointmentEntity(
                    doctorId = "doc5",
                    doctorName = "Dr. Amara Patel",
                    specialty = "Dermatologist",
                    dateTime = "May 20, 2026 - 02:00 PM",
                    status = "COMPLETED",
                    reasonForVisit = "Mild skin rash on forearm",
                    feePaid = 90.0
                )
            )

            prescriptionDao.insertPrescription(
                PrescriptionEntity(
                    appointmentId = appointmentId1,
                    doctorName = "Dr. Amara Patel",
                    date = "May 20, 2026",
                    medicineListJson = "Calamine Lotion (Apply twice daily), Cetirizine 10mg (1 tablet every night before sleep, 10 days)",
                    dosageNotes = "After food. Do not scratch skin.",
                    doctorNotes = "Keep the area highly dry. Wear breathable soft cotton fabrics. Re-evaluate if allergy persists after 10 days."
                )
            )

            // Seed default notifications
            notificationDao.insertNotification(
                NotificationEntity(
                    title = "Welcome to BookNheal!",
                    content = "Initialize your health passport. Update emergency info, enter your health history, and book diagnostic plans in seconds.",
                    timestamp = "Just Now",
                    type = "UPDATE"
                )
            )
            notificationDao.insertNotification(
                NotificationEntity(
                    title = "Daily Healthcare Suggestion",
                    content = "Stay active! Taking a brisk 10-minute walk after lunch lowers afternoon insulin peaks by up to 22%.",
                    timestamp = "2 Hours Ago",
                    type = "TIPS"
                )
            )
        }
    }

    // --- User Auth Core Helpers ---
    fun login(email: String, pwhash: String, onSuccess: () -> Unit) {
        viewModelScope.launch {
            isAuthLoading.value = true
            authError.value = null
            val user = userDao.getUserByEmail(email)
            if (user != null) {
                if (user.passwordHash == pwhash) {
                    currentUser.value = user
                    isOnboarded.value = true
                    onSuccess()
                    
                    // Trigger dynamic welcome reminder
                    notificationDao.insertNotification(
                        NotificationEntity(
                            title = "Authentication Secure",
                            content = "Successful login recorded at " + SimpleDateFormat("hh:mm a", Locale.getDefault()).format(Date()) + ". Safe wellness monitoring!",
                            timestamp = "Just Now",
                            type = "REMINDER"
                        )
                    )
                } else {
                    authError.value = "Invalid password. Access unauthorized."
                }
            } else {
                // To make demo mode completely frictionless, if user is not in database we register them automatically!
                val newUser = UserEntity(
                    email = email,
                    fullName = email.substringBefore("@").replaceFirstChar { it.uppercase() } + " Client",
                    phone = "9876543210",
                    passwordHash = pwhash
                )
                userDao.insertUser(newUser)
                currentUser.value = newUser
                isOnboarded.value = true
                onSuccess()
            }
            isAuthLoading.value = false
        }
    }

    fun register(name: String, email: String, phone: String, pwhash: String, onSuccess: () -> Unit) {
        viewModelScope.launch {
            isAuthLoading.value = true
            authError.value = null
            
            val existing = userDao.getUserByEmail(email)
            if (existing != null) {
                authError.value = "Account with this email already registered."
                isAuthLoading.value = false
                return@launch
            }

            val newUser = UserEntity(
                email = email,
                fullName = name,
                phone = phone,
                passwordHash = pwhash
            )
            userDao.insertUser(newUser)
            currentUser.value = newUser
            isOnboarded.value = true
            onSuccess()
            
            // Welcome notification
            notificationDao.insertNotification(
                NotificationEntity(
                    title = "Passport Generated Successful",
                    content = "Congratulations $name! Your BookNheal unified digital health profile is active. Welcome to future-ready healthcare.",
                    timestamp = "1 Min Ago",
                    type = "UPDATE"
                )
            )
            isAuthLoading.value = false
        }
    }

    fun logout() {
        currentUser.value = null
        currentBottomTab.value = "home"
        showAdminDashboard.value = false
    }

    fun updateMedicalProfile(history: String, emergency: String, insurance: String) {
        val user = currentUser.value ?: return
        viewModelScope.launch {
            val updated = user.copy(
                medicalHistory = history,
                emergencyContact = emergency,
                insuranceNumber = insurance
            )
            userDao.updateUser(updated)
            currentUser.value = updated
            
            notificationDao.insertNotification(
                NotificationEntity(
                    title = "Medical Passport Updated",
                    content = "Your clinical history database and emergency details were synced securely.",
                    timestamp = "Just Now",
                    type = "UPDATE"
                )
            )
        }
    }

    // --- Booking Logic ---
    fun proceedToBookAppointment(
        doctor: DoctorEntity,
        date: String,
        timeSlot: String,
        reason: String,
        onSuccess: () -> Unit
    ) {
        viewModelScope.launch {
            val appointment = AppointmentEntity(
                doctorId = doctor.id,
                doctorName = doctor.name,
                specialty = doctor.specialty,
                dateTime = "$date - $timeSlot",
                status = "UPCOMING",
                reasonForVisit = reason.ifEmpty { "General routine medical consultation checkup." },
                feePaid = doctor.consultationFee
            )
            val newId = appointmentDao.insertAppointment(appointment)
            val savedAppointment = appointment.copy(id = newId)
            bookingSuccessReceipt.value = savedAppointment
            
            // Produce alert notifications
            notificationDao.insertNotification(
                NotificationEntity(
                    title = "Confirm: ${doctor.name}",
                    content = "Your appointment is confirmed for $date at $timeSlot. The specialist is notified.",
                    timestamp = "Just Now",
                    type = "REMINDER"
                )
            )
            onSuccess()
        }
    }

    fun changeAppointmentStatus(appointmentId: Long, newStatus: String) {
        viewModelScope.launch {
            appointmentDao.updateAppointmentStatus(appointmentId, newStatus)
            
            if (newStatus == "COMPLETED") {
                // Generate a dummy doctor prescription automatically!
                val aptsList = appointments.value
                val apt = aptsList.firstOrNull { it.id == appointmentId }
                if (apt != null) {
                    val genericNotes = when (apt.specialty) {
                        "Cardiologist" -> "Atorvastatin 10mg (1 daily), Aspirin 75mg (1 post lunch)"
                        "Dentist" -> "Amoxicillin 500mg (3 daily for 5 days), Paracetamol 650mg if pain"
                        "Neurologist" -> "Gabapentin 300mg (1 daily), Amitriptyline 10mg (1 at night)"
                        "Orthopedic" -> "Ibuprofen 400mg (2 daily), Multivitamin osteo support (1 daily)"
                        "Dermatologist" -> "Desonide cream 0.05% (twice daily), Cetirizine 10mg"
                        else -> "Multivitamin tonic (10ml twice daily), rest and fluid ingestion."
                    }
                    prescriptionDao.insertPrescription(
                        PrescriptionEntity(
                            appointmentId = appointmentId,
                            doctorName = apt.doctorName,
                            date = apt.dateTime.substringBefore(" -"),
                            medicineListJson = genericNotes,
                            dosageNotes = "Post food as guided. Stay hydrated regularly.",
                            doctorNotes = "Synthesized automatically via BookNheal Clinical Portal. Please re-visit if clinical severity persists."
                        )
                    )
                }
            }

            notificationDao.insertNotification(
                NotificationEntity(
                    title = "Schedule Mod: Appointment #$appointmentId",
                    content = "Your appointment record with status updated safely to '$newStatus'.",
                    timestamp = "Just Now",
                    type = "REMINDER"
                )
            )
        }
    }

    // --- AI Chat Service ---
    fun sendUserMessage(text: String) {
        if (text.trim().isEmpty()) return
        chatMessages.add(ChatMessage(text, true))
        isAiThinking.value = true

        viewModelScope.launch {
            val systemInstruction = """
                You are "BookNheal AI Advisor" developed by Newtogen Private Limited. 
                You are a smart clinical medical assistant built directly into the BookNheal application.
                Provide safe, warm, smart, and simplified healthcare suggestions.
                Always add a disclaimer that your guidance is advisory and patients must schedule real examinations with BookNheal doctors.
                Reference the following clinic specialties we provide dynamically: Cardiologist, Dentist, Neurologist, Orthopedic, Dermatologist, Pediatrician.
                Suggest particular specialized clinics based on user symptoms (e.g., recommend Orthopedics for joint paint, Cardiologists for chest squeeze or heavy breath, Dermatologists for rash or dry skin issues, Neurologist for chronic migraine or numbness).
                Be sleek, concise, and structured. Use helpful bullet points.
            """.trimIndent()
            
            val aiResponseText = GeminiService.getChatResponse(text, systemInstruction)
            chatMessages.add(ChatMessage(aiResponseText, false))
            isAiThinking.value = false
            
            // Raise AI suggestion notifications
            notificationDao.insertNotification(
                NotificationEntity(
                    title = "AI Health Insights Ready",
                    content = if (aiResponseText.length > 80) aiResponseText.take(80) + "..." else aiResponseText,
                    timestamp = "Just Now",
                    type = "AI"
                )
            )
        }
    }

    fun submitSuggestedPrompt(prompt: String) {
        sendUserMessage(prompt)
    }

    // --- Telemedicine / Video Consultation ---
    fun startVideoConsultation(doctor: DoctorEntity) {
        activeConsultationDoctor.value = doctor
        isVideoCallActive.value = true
        isMicMuted.value = false
        isCameraOff.value = false
    }

    fun endVideoConsultation() {
        activeConsultationDoctor.value = null
        isVideoCallActive.value = false
        
        // Save completed consultation notification
        viewModelScope.launch {
            notificationDao.insertNotification(
                NotificationEntity(
                    title = "Telemedicine Call Finished",
                    content = "Your online video medical consultation with appointment specialist is archived. Check history for details.",
                    timestamp = "Just Now",
                    type = "UPDATE"
                )
            )
        }
    }

    fun clearAllNotifications() {
        viewModelScope.launch {
            notificationDao.markAllAsRead()
        }
    }
}
