package com.example.data

import android.content.Context
import androidx.room.*
import kotlinx.coroutines.flow.Flow

// ---------------- USER ENTITY ----------------
@Entity(tableName = "users")
data class UserEntity(
    @PrimaryKey val email: String,
    val fullName: String,
    val phone: String,
    val passwordHash: String,
    val insuranceNumber: String = "INS-9872-XYZ",
    val emergencyContact: String = "9876543210 (Spouse)",
    val medicalHistory: String = "No chronic conditions. All allergies: None."
)

// ---------------- DOCTOR ENTITY ----------------
@Entity(tableName = "doctors")
data class DoctorEntity(
    @PrimaryKey val id: String,
    val name: String,
    val specialty: String,
    val experienceYears: Int,
    val rating: Double,
    val availabilityStatus: String,
    val consultationFee: Double,
    val biography: String,
    val qualifications: String,
    val imageUrlPlaceholder: String
)

// ---------------- APPOINTMENT ENTITY ----------------
@Entity(tableName = "appointments")
data class AppointmentEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val doctorId: String,
    val doctorName: String,
    val specialty: String,
    val dateTime: String, // e.g., "May 30, 2026 - 10:00 AM"
    val status: String, // "UPCOMING", "COMPLETED", "CANCELLED"
    val reasonForVisit: String,
    val feePaid: Double
)

// ---------------- PRESCRIPTION ENTITY ----------------
@Entity(tableName = "prescriptions")
data class PrescriptionEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val appointmentId: Long,
    val doctorName: String,
    val date: String,
    val medicineListJson: String, // Comma separated or JSON string, e.g. "Amoxicillin 500mg, Paracetamol 650mg"
    val dosageNotes: String, // "dosage + frequency"
    val doctorNotes: String
)

// ---------------- NOTIFICATION ENTITY ----------------
@Entity(tableName = "notifications")
data class NotificationEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val content: String,
    val timestamp: String,
    val type: String, // "REMINDER", "TIPS", "AI", "UPDATE"
    val isRead: Boolean = false
)

// ---------------- DAO INTERFACES ----------------

@Dao
interface UserDao {
    @Query("SELECT * FROM users WHERE email = :email LIMIT 1")
    suspend fun getUserByEmail(email: String): UserEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertUser(user: UserEntity)

    @Update
    suspend fun updateUser(user: UserEntity)
}

@Dao
interface DoctorDao {
    @Query("SELECT * FROM doctors")
    fun getAllDoctorsFlow(): Flow<List<DoctorEntity>>

    @Query("SELECT * FROM doctors WHERE specialty = :specialty")
    fun getDoctorsBySpecialty(specialty: String): Flow<List<DoctorEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertDoctors(doctors: List<DoctorEntity>)

    @Query("SELECT COUNT(*) FROM doctors")
    suspend fun getDoctorCount(): Int
}

@Dao
interface AppointmentDao {
    @Query("SELECT * FROM appointments ORDER BY id DESC")
    fun getAllAppointmentsFlow(): Flow<List<AppointmentEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAppointment(appointment: AppointmentEntity): Long

    @Query("UPDATE appointments SET status = :status WHERE id = :id")
    suspend fun updateAppointmentStatus(id: Long, status: String)

    @Query("DELETE FROM appointments WHERE id = :id")
    suspend fun deleteAppointment(id: Long)
}

@Dao
interface PrescriptionDao {
    @Query("SELECT * FROM prescriptions ORDER BY id DESC")
    fun getAllPrescriptionsFlow(): Flow<List<PrescriptionEntity>>

    @Query("SELECT * FROM prescriptions WHERE appointmentId = :appointmentId LIMIT 1")
    suspend fun getPrescriptionByAppointment(appointmentId: Long): PrescriptionEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPrescription(prescription: PrescriptionEntity)
}

@Dao
interface NotificationDao {
    @Query("SELECT * FROM notifications ORDER BY id DESC")
    fun getAllNotificationsFlow(): Flow<List<NotificationEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertNotification(notification: NotificationEntity)

    @Query("UPDATE notifications SET isRead = 1 WHERE id = :id")
    suspend fun markAsRead(id: Long)

    @Query("UPDATE notifications SET isRead = 1")
    suspend fun markAllAsRead()
}

// ---------------- ROOM DATABASE ----------------

@Database(
    entities = [
        UserEntity::class,
        DoctorEntity::class,
        AppointmentEntity::class,
        PrescriptionEntity::class,
        NotificationEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class BookNhealDatabase : RoomDatabase() {
    abstract val userDao: UserDao
    abstract val doctorDao: DoctorDao
    abstract val appointmentDao: AppointmentDao
    abstract val prescriptionDao: PrescriptionDao
    abstract val notificationDao: NotificationDao

    companion object {
        @Volatile
        private var INSTANCE: BookNhealDatabase? = null

        fun getInstance(context: Context): BookNhealDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    BookNhealDatabase::class.java,
                    "booknheal_database"
                )
                .fallbackToDestructiveMigration()
                .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
