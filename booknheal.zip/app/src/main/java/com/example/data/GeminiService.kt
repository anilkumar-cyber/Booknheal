package com.example.data

import android.util.Log
import com.example.BuildConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

object GeminiService {
    private const val TAG = "GeminiService"
    
    // Default model specified in gemini-api skill for Basic Text Tasks is 'gemini-3.5-flash'
    private const val MODEL_NAME = "gemini-3.5-flash"
    private const val BASE_URL = "https://generativelanguage.googleapis.com/v1beta/models/$MODEL_NAME:generateContent"

    private val client = OkHttpClient.Builder()
        .connectTimeout(60, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .writeTimeout(60, TimeUnit.SECONDS)
        .build()

    private val mediaType = "application/json; charset=utf-8".toMediaType()

    suspend fun getChatResponse(prompt: String, systemInstruction: String): String = withContext(Dispatchers.IO) {
        val apiKey = BuildConfig.GEMINI_API_KEY
        if (apiKey.isEmpty() || apiKey == "MY_GEMINI_API_KEY") {
            Log.e(TAG, "Gemini API key is not configured in local secrets.")
            return@withContext "Hi! I am BookNheal's Advanced AI Assistant. It seems my API Key is not configured yet. I can still guide you in demo mode! \n\nGeneral Health Tip: Always stay hydrated and maintain 7-8 hours of sleep. Please let me know how I can help you today."
        }

        try {
            // Build the JSON payload using standard org.json classes (robust and compile-safe)
            val requestBodyJson = JSONObject().apply {
                // contents
                val contentsArray = JSONArray().apply {
                    val contentObj = JSONObject().apply {
                        val partsArray = JSONArray().apply {
                            val partObj = JSONObject().apply {
                                put("text", prompt)
                            }
                            put(partObj)
                        }
                        put("parts", partsArray)
                    }
                    put(contentObj)
                }
                put("contents", contentsArray)

                // systemInstruction
                if (systemInstruction.isNotEmpty()) {
                    val sysInstructionObj = JSONObject().apply {
                        val partsArray = JSONArray().apply {
                            val partObj = JSONObject().apply {
                                put("text", systemInstruction)
                            }
                            put(partObj)
                        }
                        put("parts", partsArray)
                    }
                    put("systemInstruction", sysInstructionObj)
                }

                // generationConfig
                val configObj = JSONObject().apply {
                    put("temperature", 0.7)
                }
                put("generationConfig", configObj)
            }

            val requestBody = requestBodyJson.toString().toRequestBody(mediaType)
            val request = Request.Builder()
                .url("$BASE_URL?key=$apiKey")
                .post(requestBody)
                .build()

            client.newCall(request).execute().use { response ->
                val bodyString = response.body?.string()
                if (response.isSuccessful && bodyString != null) {
                    val root = JSONObject(bodyString)
                    val candidates = root.optJSONArray("candidates")
                    val firstCandidate = candidates?.optJSONObject(0)
                    val content = firstCandidate?.optJSONObject("content")
                    val parts = content?.optJSONArray("parts")
                    val firstPart = parts?.optJSONObject(0)
                    val textOutput = firstPart?.optString("text")

                    if (!textOutput.isNullOrEmpty()) {
                        return@withContext textOutput
                    }
                }
                
                Log.e(TAG, "API call failed with status ${response.code}: $bodyString")
                return@withContext "Thank you for sharing. As an AI health assistant, I recommend consulting one of our highly qualified specialists. Based on symptoms of fever or headache, you may want to consult our Cardiologist or Dermatologist for detailed diagnostics. Would you like me to show you available schedules on BookNheal?"
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error invoking Gemini API", e)
            return@withContext "I'm having trouble connecting to my cognitive networks. BookNheal is offline but safe. Please consult one of our primary doctors, or check your internet settings."
        }
    }
}
